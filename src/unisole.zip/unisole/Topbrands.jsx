import Card from 'react-bootstrap/Card';
import CardGroup from 'react-bootstrap/CardGroup';
import ronaldonike from '../unisole/Images/ronaldo_Nike.png'
import ronaldo_logo_nike from '../unisole/Images/ronaldo_logo_nike.png'
import kohli_puma from '../unisole/Images/kohli_puma.png'
import kohli_puma_logo from '../unisole/Images/kohli_puma_logo.png'
import jordan from '../unisole/Images/jordan.png'
import jordan_logo from '../unisole/Images/jordan_logo.png'
import varun_reebook from '../unisole/Images/varun_reebook.png'
import varun_reebook_logo from '../unisole/Images/varun_reebook_logo.png'
import frame1 from '../unisole/Images/Frame 1.png'
import frame2 from '../unisole/Images/Frame 2.png'
import frame3 from '../unisole/Images/Frame 3.png'
import frame4 from '../unisole/Images/Frame 4.png'

function Topbrands() {
    return (
        <div>
            <div className="w-100">
                <div className="w-1140 m-auto">
                    <div className='d-flex align-item-center mb-5'>
                        <div className="w-50">
                            <p className='fs-2 inter fw-bold'>We provide best customer experiences</p>
                        </div>
                        <div className="w-50 ps-3 border border-2 border-dark border-start-1 border-end-0 border-top-0 border-bottom-0">
                            <p className='m-0 h-112 line-h-112'>We ensure our customers have the best shopping experience</p>
                        </div>
                    </div>
                    <div className='d-flex gap-5 mb-5'>
                        <div className="w-25" style={{ width: "291px", height: "125px" }}>
                            <div>
                                <img src={frame1} alt="" style={{ width: "40px", height: "35px" }} />
                                <p className='fw-bold inter'>Original Products</p>
                                <p className='inter'>We provide money back guarantee if the product are not original.</p>
                            </div>
                        </div>
                        <div className="w-25">
                            <div>
                                <img src={frame2} alt="" style={{ width: "40px", height: "35px" }} />
                                <p className='fw-bold inter'>Satisfaction Guarantee</p>
                                <p className='inter'>Exchange the product you’ve purchased if doesn’t fit on you.</p>
                            </div>
                        </div>
                        <div className="w-25">
                            <div>
                                <img src={frame3} alt="" style={{ width: "40px", height: "35px" }} />
                                <p className='fw-bold inter'>New Arrival Everyday</p>
                                <p className='inter'>We updates our collection almost everyday.</p>
                            </div>
                        </div>
                        <div className="w-25">
                            <div>
                                <img src={frame4} alt="" style={{ width: "40px", height: "35px" }} />
                                <p className='fw-bold inter'>Fast & Free Shipping</p>
                                <p className='inter'>We offer fast and free shipping for our loyal customers.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <p className='reem-kufi fs-3 text-decoration-underline mt-3'>Explore Top Brands</p>
            </div>
            <CardGroup className='d-flex gap-3'>
                <Card className='d-flex flex-column topbrandcard px-5 py-2'>
                    <div className="d-flex justify-content-center">
                        <Card.Img variant="top" src={ronaldonike} />
                    </div>
                    <Card.Body>
                        <Card.Title className='topcardtitleimg d-flex justify-content-center'>
                            <img src={ronaldo_logo_nike} alt="" />
                        </Card.Title>
                    </Card.Body>
                </Card>
                <Card className='d-flex flex-column topbrandcard px-5 py-2'>
                    <div className="d-flex justify-content-center">
                        <Card.Img variant="top" src={kohli_puma} />
                    </div>
                    <Card.Body>
                        <Card.Title className='topcardtitleimg d-flex justify-content-center topcardtitleset'>
                            <img src={kohli_puma_logo} alt="" />
                        </Card.Title>
                    </Card.Body>
                </Card>
                <Card className='d-flex flex-column topbrandcard px-5 py-2'>
                    <div className="d-flex justify-content-center">
                        <Card.Img variant="top" src={jordan} />
                    </div>
                    <Card.Body>
                        <Card.Title className='topcardtitleimg d-flex justify-content-center topcardtitleset'>
                            <img src={jordan_logo} alt="" />
                        </Card.Title>
                    </Card.Body>
                </Card>
                <Card className='d-flex flex-column topbrandcard px-5 py-2'>
                    <div className="d-flex justify-content-center">
                        <Card.Img variant="top" src={varun_reebook} />
                    </div>
                    <Card.Body>
                        <Card.Title className='topcardtitleimg d-flex justify-content-center'>
                            <img src={varun_reebook_logo} alt="" />
                        </Card.Title>
                    </Card.Body>
                </Card>
            </CardGroup>
        </div>
    );
}

export default Topbrands;